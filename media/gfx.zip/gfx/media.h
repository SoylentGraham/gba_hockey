#ifndef MEDIA_MEDIA_H
#define MEDIA_MEDIA_H



#include "../../core/gba.h"
#include "../../core/types.h"


const u16 gfx_palette[256];

const u16 font_tile_data[ 8*376 ];
const u16 blank_tile_data[ 8*16 ] ;

const u16 hockey_guy_body_data[ 8*640 ] ;
const u16 hockey_guy_head_data[ 8*200 ] ;

const u16 targets_tile_data[8*64];
const u16 arrows_tile_data[8*64];


const u16 puck_sprite_data[ 8*8 ] ;
const u16 puck_mask_data[8*8] ;
const u16 rink_markings_tiles[120*8] ;
const u16 scoreboard_lights_tiles[8*248];

const u16 ice_rink_tile_data[ 8*280 ] ;
const u16 ice_rink_mask_data[ 8*280 ] ;


const u16 generic_mask_data[ 8*8 ];

//hockey stick angles
const u16 hockey_sticks_tile_data[8*32];



//u8 masks
const u8 generic_mask_u8[8]; //8*y
const u8 rink_tile_mask_u8[280];
const u8 puck_mask_u8[8];

#define PUCK_MASK(n) ((u8*)puck_mask_data)





#endif
